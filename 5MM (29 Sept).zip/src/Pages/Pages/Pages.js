import React from 'react';
import './Pages.css';
import Home from '../Home/Home/Home';

const Pages = () => {
  return (
    <div className='all-page-os'>        
        <Home />
    </div>
  )
}

export default Pages;
