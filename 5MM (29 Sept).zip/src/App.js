import './App.css';
import Pages from './Pages/Pages/Pages';

function App() {
  return (
    <div className="App">
      <Pages />
    </div>
  );
}

export default App;
